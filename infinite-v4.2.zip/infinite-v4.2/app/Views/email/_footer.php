<style>
    .wrapper table tr td img {
        height: auto !important;
    }
</style>
</body>
</html>